import React from "react";

const Error = ({ message }) => {
  return <p>{message}</p>;
};

export default Error;
